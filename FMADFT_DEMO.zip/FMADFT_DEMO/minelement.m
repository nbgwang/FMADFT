function f = minelement(H)
% function f = minelement(H)
% 
% The routine finds the minimum absolute non-zero value of the real and 
% imaginary parts among all non-zero elements of H.
% 
% Input:
% H: a matrix of any size
% 
% Output:
% f: (1 x 1), the minimum absolute non-zero value of the real and imaginary 
% parts among all non-zero elements of H
% 
% Reference: 
% D. Lin, G. Wang, and K. C. Ho, "A Fast Multiplierless DFT Approximation 
% by Sparse Factorization Optimization"

SmallConstant = 1e-14;   % small constant for detecting non-zero values

tmpr = abs(real(H(:)));
tmpr = tmpr(find(tmpr>SmallConstant));
tmpi = abs(imag(H(:)));
tmpi = tmpi(find(tmpi>SmallConstant));
f = min([tmpr;tmpi]);
