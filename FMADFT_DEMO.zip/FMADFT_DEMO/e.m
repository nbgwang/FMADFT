function x = e(a,b)
% function x = e(a,b)
% 
% Input:
% a: (1 x 1), the position of 1
% b: (1 x 1), the length of the unit vector
% 
% Output:
% x: (b x 1), the a-th column of the (b x b) identity matrix
% 
% Reference: 
% D. Lin, G. Wang, and K. C. Ho ``A Fast Multiplierless DFT Approximation 
% by Sparse Factorization Optimization''

x=zeros(b,1);
x(a)=1;

end