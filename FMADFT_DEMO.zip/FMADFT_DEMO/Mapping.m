function Ahat = Mapping(A,S)
% function Ahat = Mapping(A,S)  
% 
% Input:
% A: (N x N), the matrix factor
% S: the feasible set
% 
% Output:
% Ahat: (N x N), the approximate version of A by using the feasible set S
% 
% Reference: 
% D. Lin, G. Wang, and K. C. Ho, "A Fast Multiplierless DFT Approximation 
% by Sparse Factorization Optimization"

S=S';

[M,N] = size(A);
Ahat = A;
Ar = real(A);
tmp = reshape(Ar,M*N,1);
df = (repmat(tmp,1,length(S))-repmat(S,length(tmp),1)).^2;
[minVal,minIdx] = min(df,[],2);
for i = 1:length(tmp),
    tmp(i) = S(minIdx(i));
end;
Ahatr=reshape(tmp,M,N);

Ai = imag(A);
tmp = reshape(Ai,M*N,1);
df = (repmat(tmp,1,length(S))-repmat(S,length(tmp),1)).^2;
[minVal,minIdx] = min(df,[],2);
for i = 1:length(tmp),
    tmp(i) = S(minIdx(i));
end;
Ahati = reshape(tmp,M,N);

Ahat = Ahatr+1j*Ahati;

end