function l = Adder_Count(H)
% function l = Adder_Count(H)

SmallConstant = 1e-14;   % small constant for detecting non-zero values

[M,N,I] = size(H);
l = 0;

for i = 1:I,
    tmp = (abs(squeeze(H(:,:,i)))>=SmallConstant);
    tmp = sum(tmp,2);
    l = l+length(find(tmp==2));
end;

end