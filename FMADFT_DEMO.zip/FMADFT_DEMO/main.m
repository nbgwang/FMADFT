% This code gives a demo for the fast multiplierless approximation (FMA) DFT and evaluates the performance.
%
% The routine FMA_DFT generates the DFT approximation.
%
% Reference: 
% D. Lin, G. Wang, and K. C. Ho "A Fast Multiplierless Discrete Fourier 
% Transform Approximation by Sparse Factorization Optimization", IEEE Signal Processing Magazine, 2025.
%

% IMPORTANT NOTE: The code is free to use for academic research purposes. For industrial use of the related code/method, please contact Prof. Gang Wang (wanggang@nbu.edu.cn) for licensing.

%  Copyright (C) 2025
%  Ningbo University
%  Ningbo, 315211, China.
%  wanggang@nbu.edu.cn


clear
clc

N = 2^10;   % DFT Length
FeasibleSet='P';   % 'P' or 'N'   

[P,Hhat,Ahat,beta,Fhat] = FMA_DFT(N,FeasibleSet);

i = 1:N; k = 1:N;  
F = exp(-1j*2*pi/N*(k-1)'*(i-1));   

% -------------------------Performance Evaluation--------------------------
%================Approximation Error=================
e = norm(F-Fhat,'fro')^2/norm(F,'fro')^2
%================Near-Orthogonality==================
phi = 1-norm(diag(Fhat*(Fhat)'),'fro')/norm(Fhat*(Fhat)','fro')    
%==============Arithmetic Complexity=================
No_of_adders= Adder_Count(Ahat)+Adder_Count(Hhat)

