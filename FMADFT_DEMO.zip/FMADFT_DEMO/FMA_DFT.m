function [P,Hhat,Ahat,beta,Fhat] = FMA_DFT(N,FeasibleSet)  
% function [P,Hhat,Ahat,beta,Fhat] = FMA_DFT(N,FeasbileSet)    
% 
% The routine works for both P and N sets
% 
% Input:
% N: (1 x 1), the DFT length
% FeasbileSet: 'P' or 'N', selection of feasible set    
% 
% Output:
% P: (N x N), the permutation matrix
% Hhat: (N x N x log2(N)), the calibration matrices
% Ahat: (N x N x log2(N)), the mapped matrix factors
% beta: (1 x 1), scaling parameter 
% Fhat: (N x N), the approximate DFT matrix
% 
% Reference: 
% D. Lin, G. Wang, and K. C. Ho, "A Fast Multiplierless DFT Approximation 
% by Sparse Factorization Optimization"

i = 1:N; k = 1:N;   
F = exp(-1j*2*pi/N*(k-1)'*(i-1)); 

t = log2(N);
w = exp(-1j*2*pi/N);

% -----------------------Permutation Matrix P------------------------------
NaturalOder = 0:N-1;
BitReversedOder = bitrevorder(NaturalOder);
P = bitrevorder(eye(N)); % the permutation matrix
% ------------------------The Exact Sparse Factorization-------------------
for i = 1:t
    Ac = [];    
    for ii = 1:N/(2^i)  
        Ac = blkdiag(Ac,[1,w^(BitReversedOder(2*ii-1));1,w^(BitReversedOder(2*ii))]);  
    end
    I = eye(2^(i-1));
    A(:,:,i) = kron(Ac,I); % the exact DFT decomposition matrix factors
end
% ----------------------------Ahat & Hhat----------------------------------
% =========Using the Feasible Set N===========
if (FeasibleSet=='N')  
    Nset = [0;1/2;-1/2;1;-1]; % the feasible set N  
    Ahat = zeros(N,N,t);    
    Hhat = zeros(N,N,t);    
    Fhat = P;
    for i = 1:t
        Hhat(:,:,i) = eye(N);
        if i<t-1
            Ahat(:,:,i) = Mapping(A(:,:,i),Nset);
        else
            Ahat(:,:,i) = A(:,:,i);
        end
        Fhat = Fhat*Ahat(:,:,i);
    end
    beta = real(trace(F'*Fhat))/trace(Fhat'*Fhat);
    Fhat = beta.*Fhat;
% =========Using the Feasible Set P===========
elseif (FeasibleSet=='P')   
    Ahat = zeros(N,N,t);    
    Hhat = zeros(N,N,t);    
    Pset = 0; % the feasible set P
    q = 0; % initialize q
    for l = 0:q
        Pset = [Pset;-2^l;2^l];
    end
    Fhat = P;
    for i = 1:t
        if i<t-1
            Ahat(:,:,i) = Mapping(A(:,:,i),Pset);%mapping of the matrix factors
            Hbar(:,:,i) = A(:,:,i)*inv(Ahat(:,:,i));
            [epsilon] = minelement(Hbar(:,:,i));  % find the minimum absolute value
            alpha(i) = 2^(round(log2(1/epsilon))); % the scale-up factor
        end
    end
    q = log2(max(alpha)); % update q
%     for l = 1:q
%         Pset = [Pset;-2^l;2^l]; % update the P set
%     end
    Pset = [-2.^(0:q)'; 0; 2.^(0:q)']; % update the P set 
    for i = 1:t    
        if i<t-1
            Hhat(:,:,i) = Mapping(Hbar(:,:,i).*alpha(i),Pset);%mapping of the calibration matrices
        else
            Ahat(:,:,i) = A(:,:,i);
            Hhat(:,:,i) = eye(N);
        end
        Fhat = Fhat*Hhat(:,:,i)*Ahat(:,:,i);
    end
    beta = real(trace((F)'*Fhat))/trace((Fhat)'*Fhat);
    Fhat = beta.*Fhat;
end

end